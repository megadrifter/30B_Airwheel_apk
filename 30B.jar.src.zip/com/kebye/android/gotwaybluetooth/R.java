package com.kebye.android.gotwaybluetooth;

public final class R
{
  public static final class attr {}
  
  public static final class drawable
  {
    public static final int app_icon = 2130837504;
    public static final int btbeen = 2130837505;
    public static final int btbeenpress = 2130837506;
    public static final int bteen = 2130837507;
    public static final int ic_launcher = 2130837508;
    public static final int startpic = 2130837509;
  }
  
  public static final class id
  {
    public static final int about = 2131099672;
    public static final int advance = 2131099684;
    public static final int auto_flash_tem = 2131099692;
    public static final int beenfive = 2131099685;
    public static final int button_scan = 2131099654;
    public static final int close_speed_alart1 = 2131099699;
    public static final int close_speed_alart_all = 2131099700;
    public static final int close_vibration = 2131099683;
    public static final int continuous_show_tem = 2131099693;
    public static final int flash_tem_120_sec = 2131099697;
    public static final int flash_tem_15_sec = 2131099694;
    public static final int flash_tem_30_sec = 2131099695;
    public static final int flash_tem_60_sec = 2131099696;
    public static final int iBtbeen = 2131099668;
    public static final int imbtadvanced = 2131099656;
    public static final int insecure_connect_scan = 2131099674;
    public static final int jiaozhun = 2131099686;
    public static final int jiaozhunhelp = 2131099670;
    public static final int linkbluetoothhelp = 2131099669;
    public static final int new_devices = 2131099653;
    public static final int open_speed_alart = 2131099701;
    public static final int paired_devices = 2131099651;
    public static final int secure_connect_scan = 2131099673;
    public static final int set_speed_alart = 2131099698;
    public static final int sethard = 2131099687;
    public static final int setmiddle = 2131099688;
    public static final int setsoft = 2131099689;
    public static final int setsofthardhelp = 2131099671;
    public static final int showcurrent = 2131099690;
    public static final int showtem = 2131099691;
    public static final int speed_13_vibration = 2131099677;
    public static final int speed_16_vibration = 2131099678;
    public static final int speed_19_vibration = 2131099679;
    public static final int speed_22_vibration = 2131099680;
    public static final int speed_25_vibration = 2131099681;
    public static final int speed_28_vibration = 2131099682;
    public static final int textView1 = 2131099655;
    public static final int title_left_text = 2131099648;
    public static final int title_new_devices = 2131099652;
    public static final int title_paired_devices = 2131099650;
    public static final int title_right_text = 2131099649;
    public static final int tvEnergy = 2131099663;
    public static final int tvEnergyLable = 2131099662;
    public static final int tvGo = 2131099665;
    public static final int tvGoLable = 2131099664;
    public static final int tvSpeedLable = 2131099658;
    public static final int tvSpeedOut = 2131099659;
    public static final int tvTem = 2131099667;
    public static final int tvTemLable = 2131099666;
    public static final int tvV = 2131099661;
    public static final int tvVLable = 2131099660;
    public static final int tvadvancedshow = 2131099657;
    public static final int vibration_warn = 2131099675;
    public static final int vibration_warn_group = 2131099676;
  }
  
  public static final class layout
  {
    public static final int custom_title = 2130903040;
    public static final int device_list = 2130903041;
    public static final int device_name = 2130903042;
    public static final int gotwayadvanced = 2130903043;
    public static final int main = 2130903044;
    public static final int message = 2130903045;
    public static final int startpic = 2130903046;
  }
  
  public static final class menu
  {
    public static final int advanced_option_menu = 2131034112;
    public static final int option_menu = 2131034113;
  }
  
  public static final class string
  {
    public static final int about = 2130968606;
    public static final int advance = 2130968593;
    public static final int advancedTitle = 2130968594;
    public static final int app_name = 2130968576;
    public static final int beenfive = 2130968600;
    public static final int bt_not_enabled_leaving = 2130968579;
    public static final int button_scan = 2130968589;
    public static final int insecure_connect = 2130968591;
    public static final int jiaozhun = 2130968597;
    public static final int jiaozhunhelp = 2130968601;
    public static final int linkbluetooth = 2130968603;
    public static final int main_title = 2130968595;
    public static final int none_found = 2130968586;
    public static final int none_paired = 2130968585;
    public static final int not_connected = 2130968578;
    public static final int other_fuction = 2130968596;
    public static final int scanning = 2130968583;
    public static final int secure_connect = 2130968590;
    public static final int select_device = 2130968584;
    public static final int send = 2130968577;
    public static final int sethard = 2130968598;
    public static final int setmiddle = 2130968605;
    public static final int setsoft = 2130968599;
    public static final int setsofthard = 2130968602;
    public static final int showcurrent = 2130968604;
    public static final int showtem = 2130968592;
    public static final int title_connected_to = 2130968581;
    public static final int title_connecting = 2130968580;
    public static final int title_not_connected = 2130968582;
    public static final int title_other_devices = 2130968588;
    public static final int title_paired_devices = 2130968587;
    public static final int vibration_warn = 2130968607;
  }
}


/* Location:              M:\Airwheel\Приложение\30B.jar!\com\kebye\android\gotwaybluetooth\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */