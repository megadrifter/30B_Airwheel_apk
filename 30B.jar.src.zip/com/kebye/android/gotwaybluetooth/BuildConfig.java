package com.kebye.android.gotwaybluetooth;

public final class BuildConfig
{
  public static final boolean DEBUG = false;
}


/* Location:              M:\Airwheel\Приложение\30B.jar!\com\kebye\android\gotwaybluetooth\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */